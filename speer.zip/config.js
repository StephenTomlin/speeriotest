export default {
    "jwtSecret": "a secret phrase!!!"
}