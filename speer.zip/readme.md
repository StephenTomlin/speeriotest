steps to run:
install psqlpostgres
run commands in ./db/scaffold/init on the sql server
npm install

setup to run tests:
npm test




things im proud of in this project:

the seperation between the express app - router - and DB

github profile:
https://github.com/StephenTomlin

note: i have been in the field for the past ~3.5 years so whats on there doesnt neccessarily reflect my current knowledge.

